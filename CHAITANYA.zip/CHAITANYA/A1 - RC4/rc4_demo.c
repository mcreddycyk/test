#include<stdio.h>

#define KEYLEN 8
#define SIZE 256
#define BYTESIZE 8
#define NROUNDS 10

void intializeKey(int *K)
{
	int i;
	for(i=0; i<KEYLEN; i++)
	{
		K[i] = -1;
	}
}


void initialize(int *S, int *T, int *K)
{
	int i;
	for(i=0; i<255; i++)
	{
		S[i] = i;
		T[i] = K[i % KEYLEN];
	}
}

void permutation(int *S, int *T)
{
	int i, j=0;
	
	int temp;
	
	for(i =0; i<255; i++)
	{
		j=(j + S[i] + T[i]) % 256;
		//swap S[i], S[j]
		temp = S[i];
		S[i] = S[j];
		S[j] = temp;
	}
}

void keyGeneration(int *S, int *T, int *key)
{
	int t, k, i, j;
	i =0; j =0;
	
	int temp;
	
	int round = 0;
	while(round < NROUNDS)
	{
		i = (i + 1) % 256;
		j = (j + S[i]) % 256;
		//Swap (S[i], S[j]);
		temp = S[i];
		S[i] = S[j];
		S[j] = temp;
		
		t = (S[i] + S[j]) % 256;
		k = S[t];
		
		key[round] = k;
		
		printf("	Byte[%d]: %d\n", round++, k);
	}
	
}

void encryptMessage(int *message, int *keyStream, int *cipherText)
{
	int i;
	for(i=0; i<NROUNDS; i++)
	{
		cipherText[i] = message[i] ^ keyStream[i];
	}
	
	//exor
}

int main()
{
	int S[SIZE];
	int T[SIZE];
	int K[KEYLEN] = {2, 4, 9, 7, 1, 1, 3, 4};
	
	initialize(S, T, K);	
	permutation(S, T);
	
	int keyStream[NROUNDS];
	printf("Generating %d byte KeyStream....\n", NROUNDS);
	keyGeneration(S, T, keyStream);
	
	return 0;
}


