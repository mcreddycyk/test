#include<stdio.h>
#include<stdlib.h> 
#include<math.h>

#define CONST 256
#define KEYLEN 8
#define GPOLYNUM 33
#define FALSE 0
#define TRUE 1

int G[GPOLYNUM] = {1,0,0,0,0,0,1,0,0,1,1,0,0,0,0,0,1,0,0,0,1,1,1,0,1,1,0,1,1,0,1,1,1};

int NROUNDS = 0;
int totalMsgSizeInBytes = 0;
int nMSGBYTES = 0;
int totalMsgSizeInBits = 0;

int randomByte()
{
    return (rand() % 256);
}

int initialize(int *S, int *T, int *K)
{
    int i;
    for(i = 0; i < 256; i++)
    {
        S[i] = i;
        T[i] = K[i % KEYLEN];
    }
    
}

int permutation(int *S, int *T)
{
    int j = 0;
    int i, temp;
    for(i = 0; i < 256; i++)
    {
        j = (j + S[i] + T[i]) % 256;
        //swap S[i], S[j]
        temp = S[i];
        S[i] = S[j];
        S[j] = temp;
    }
    
}

void keyGeneration(int *S, int *T, int *keyStream)
{
    int t, k, i, j;
    i = 0; j = 0;
    
    int temp;
    
    int round = 0;
    printf("\nKEY STREAM GENERATED:\n");
    while(round < NROUNDS)
    {
        i = (i + 1) % 256;
        j = (j + S[i]) % 256;
        //Swap (S[i], S[j]);
        temp = S[i];
        S[i] = S[j];
        S[j] = temp;
        
        t = (S[i] + S[j]) % 256;
        k = S[t];
        
        keyStream[round] = k;
        
        printf("\t[%d]: %d\n", round++, k);
    }
    
}

void convertNumberToBits(int number, int *numberInBits)
{
    int temp = number;
    int i;
    for(i = 7; i >= 0; i--)
    {
        numberInBits[i] = temp % 2;
        temp = temp / 2;
    }
}

void calculateCRC(int CRC32ZeroAppendedMsgInBits[])
{
    //calculation of crc
    int k, p, r, q, prev = 0;
    int tag = 0;
    
    //jump to 1st one
    while(tag < totalMsgSizeInBits)
    {
        if(CRC32ZeroAppendedMsgInBits[tag] == 1)
        {
            break;
        }
        else
        {
            tag++;
        }
    }
    
    k = tag;
    
    while((tag+GPOLYNUM-1) < totalMsgSizeInBits)
    { 
        k = tag;
        
        for(p = 0; p < GPOLYNUM; p++)
        {
            r = (CRC32ZeroAppendedMsgInBits[k] + G[p]) % 2;
            //printf("xor: %d\n", r);
            if(r == 0 && (p == 0 || prev == 0))
            {
                //printf("\n*\n");
                prev = 0;
                tag++;
            }
            else
            {
                //printf("\n$\n");
                prev = 1;
            }
            
            CRC32ZeroAppendedMsgInBits[k] = r;
            
            k++;
        }
        
        //test print
        /*
        printf("\nDEBUGG REMAINDER POLY:\n");
        int q;
        for(q = 0; q < totalMsgSizeInBits; q++)
        {
            printf("%d ", CRC32ZeroAppendedMsgInBits[q]);
        }
        printf("\n");
        */    
    }
}


void convertToBits(int *CRC32ZeroAppendedMsg, int *CRC32ZeroAppendedMsgInBits)
{
    int i = 0, j, number;
    int numberInBits[8];
    while(i < totalMsgSizeInBits)
    {
        number = CRC32ZeroAppendedMsg[i/8];
        convertNumberToBits(number, numberInBits);
        for(j = 0; j < 8; j++)
        {
            CRC32ZeroAppendedMsgInBits[i] = numberInBits[j]; 
            //DuplicateCRC32ZeroAppendedMsgInBits[i] = numberInBits[j]; 
            
            i++;
            
            printf("%d", numberInBits[j]);
        }
        printf("\n");
    }
}

void duplicateMessageInBits(int *input, int *output)
{
    int i = 0;
    while(i < totalMsgSizeInBits)
    {
        output[i] = input[i];
        i++;
    }
}

void duplicateMessageInBytes(int *input, int *output)
{
    int i = 0;
    while(i < totalMsgSizeInBytes)
    {
        output[i] = input[i];
        i++;
    }
}
void calculateCRC32AndAppendRemainder(int *CRC32ZeroAppendedMsg, int *CRC32ResultantMsg)
{

    totalMsgSizeInBits = totalMsgSizeInBytes * 8;
    int CRC32ZeroAppendedMsgInBits[totalMsgSizeInBits], DuplicateCRC32ZeroAppendedMsgInBits[totalMsgSizeInBits];    
    convertToBits(CRC32ZeroAppendedMsg, CRC32ZeroAppendedMsgInBits);
    duplicateMessageInBits(CRC32ZeroAppendedMsgInBits, DuplicateCRC32ZeroAppendedMsgInBits);

    calculateCRC(CRC32ZeroAppendedMsgInBits);

    printf("\nREMAINDER POLY:\n");
    int q;
    for(q = 0; q < totalMsgSizeInBits; q++)
    {
        printf("%d ", CRC32ZeroAppendedMsgInBits[q]);
    }
    printf("\n");
    
    int x;
    int CRC32ResultantMsgInBits[totalMsgSizeInBits];
    for(x = 0; x < totalMsgSizeInBits; x++)
    {
        CRC32ResultantMsgInBits[x] = CRC32ZeroAppendedMsgInBits[x] + DuplicateCRC32ZeroAppendedMsgInBits[x];
    }
    
    printf("\nCRCED MESSAGE:\n");
    int y;
    for(y = 0; y < totalMsgSizeInBits; y++)
    {
        printf("%d ", CRC32ResultantMsgInBits[y]);
    }
    printf("\n");
    
    int x1, y1, bit, val = 0;
    for(x1 = 0; x1 < totalMsgSizeInBytes; x1++)
    {
        for(y1 = 0; y1 < 8; y1++)
        {
            bit = CRC32ResultantMsgInBits[x1*8 + y1];
            val = val + bit * (pow(2, 7-y1));
        }
        
        CRC32ResultantMsg[x1] = val;
        val = 0;
    }
}

void encrypt(int *CRC32ResultantMsg, int *keyStream, int *cipherText)
{
    int i;
    for(i = 0; i < totalMsgSizeInBytes; i++)
    {
        cipherText[i] = CRC32ResultantMsg[i] ^ keyStream[i];
    }
}

void generateRandomKey(int *K)
{
    printf("\nRANDOMLY GENERATED KEY:\n");
    
    int i, j;
    for(i = 0; i < KEYLEN; i++)
    {
        K[i] = randomByte();
        printf("\t%d", K[i]);
    }
    printf("\n\n\n");
}

int scanMsgAndAppendZeros(int *CRC32ZeroAppendedMsg)
{
    int x;
    for(x = 0; x < nMSGBYTES; x++)
    {
        scanf("%d", CRC32ZeroAppendedMsg + x);
    }
    while(x < totalMsgSizeInBytes)
    {
        CRC32ZeroAppendedMsg[x] = 0;
        x++;
    }
}

void decrypt(int *MSGICV, int *cipherText, int *keyStream)
{
    int y1;
    printf("\nMSGICV:\n");
    for(y1 = 0; y1 < totalMsgSizeInBytes; y1++)
    {
        MSGICV[y1] = cipherText[y1] ^ keyStream[y1];
        printf("%d ", MSGICV[y1]);
    }
    printf("\n");
}

int calculateCRC32AndValidateMessage(int *MSGICV, int *DuplicateMSGICV, int *valid)
{
    duplicateMessageInBytes(MSGICV, DuplicateMSGICV);
    
    int MSGICVinBits[totalMsgSizeInBits];
    convertToBits(MSGICV, MSGICVinBits);

    calculateCRC(MSGICVinBits);

    printf("\nCRC REMAINDER POLY:\n");
    int q;
    for(q = 0; q < totalMsgSizeInBits; q++)
    {
        printf("%d ", MSGICVinBits[q]);
    }
    printf("\n");
    
    int i;
    for(i = 0; i < totalMsgSizeInBits; i++)
    {
        if(MSGICVinBits[i] == 1)
        {
            *valid = FALSE;
            break;
        }
    }
}



int main()
{
    int K[KEYLEN]; //64bits
    generateRandomKey(K);
    
    int S[CONST], T[CONST]; //arrays of size 256
    initialize(S, T, K);
    permutation(S, T);
    
    //calculate msg || CRC-32(message) beforehand to..
    //..get number of key stream bytes to be generated
    printf("#MESSAGE BYTES: ");
    
    scanf("%d", &nMSGBYTES);
    
    int nCRC32AppendBytes = 4;
    totalMsgSizeInBytes = nMSGBYTES + nCRC32AppendBytes;
    
    int CRC32ZeroAppendedMsg[totalMsgSizeInBytes];
    //scanning the input message and appendng 4 bytes zeros to the message
    scanMsgAndAppendZeros(CRC32ZeroAppendedMsg);
    
    int CRC32ResultantMsg[totalMsgSizeInBytes];
    //calculating crc32 remainder seperately and adding to zero appended message
    calculateCRC32AndAppendRemainder(CRC32ZeroAppendedMsg, CRC32ResultantMsg);
    
    
    int y;
    //final message to be encrypted with integrity check involved
    printf("\nnATTACKER CRCED BYTE MESSAGE:\n");
    for(y = 0; y < totalMsgSizeInBytes; y++)
    {
        printf("%d ", CRC32ResultantMsg[y]);
    }
    
    //no of keystream bytes depends 
    //on message and CRC-32 length
    NROUNDS = totalMsgSizeInBytes;
    int keyStream[NROUNDS];
    
    //generating key stream based on number of bytes to be encrypted
    keyGeneration(S, T, keyStream);
    
    int cipherText[NROUNDS];
    //encrypting resultant message and key stream 
    encrypt(CRC32ResultantMsg, keyStream, cipherText);
    
    int x1;
    //final cipher text to be transmitted
    printf("\nATTACKER CIPHER TEXT:\n");
    for(x1 = 0; x1 < totalMsgSizeInBytes; x1++)
    {
        printf("%d ", cipherText[x1]);    
    }
    printf("\n");
    
    
    //client////////////////////
    ////////////////////////////////////////////////////////////
    
     int CRC32ZeroAppendedMsg2[totalMsgSizeInBytes];
    //scanning the input message and appendng 4 bytes zeros to the message
    printf("\nCLIENT MESSAGE:\n");
    scanMsgAndAppendZeros(CRC32ZeroAppendedMsg2);
    
    int CRC32ResultantMsg2[totalMsgSizeInBytes];
    //calculating crc32 remainder seperately and adding to zero appended message
    calculateCRC32AndAppendRemainder(CRC32ZeroAppendedMsg2, CRC32ResultantMsg2);
    
    
    int y1;
    //final message to be encrypted with integrity check involved
    printf("\nCLIENT CRCED BYTE MESSAGE:\n");
    for(y1 = 0; y1 < totalMsgSizeInBytes; y1++)
    {
        printf("%d ", CRC32ResultantMsg[y1]);
    }
    
    
    int cipherText2[NROUNDS];
    //encrypting resultant message and key stream 
    encrypt(CRC32ResultantMsg2, keyStream, cipherText2);
    
    int x2;
    //final cipher text to be transmitted
    printf("\nCLIENT CIPHER TEXT:\n");
    for(x2 = 0; x2 < totalMsgSizeInBytes; x2++)
    {
        printf("%d ", cipherText2[x2]);    
    }
    printf("\n");
    
    
    
    //finding out plaintext of client
    int x3;
    //final cipher text to be transmitted
    printf("\nEXOR OPERATION:\n");
    int attackedMessage[totalMsgSizeInBytes];
    for(x3 = 0; x3 < totalMsgSizeInBytes; x3++)
    {
       attackedMessage[x3] = cipherText2[x3] ^ cipherText[x3] ^ CRC32ResultantMsg[x3];
	    
    }
    printf("\n");
    
    printf("\n================MESSAGE ==========:\n");
    for(x3 = 0; x3 < totalMsgSizeInBytes-4; x3++)
    {
       printf("%d\n", attackedMessage[x3]);
	    
    }
    printf("\n");
    
    printf("\n================KEY STREAM==========:\n");
    for(x3 = 0; x3 < totalMsgSizeInBytes; x3++)
    {
       printf("%d\n", attackedMessage[x3] ^ cipherText2[x3]);
	    
    }
 
    return 0;    
}

