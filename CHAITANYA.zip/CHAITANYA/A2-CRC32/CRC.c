#include<stdio.h>
#define GPOLYNUM 33
#define FALSE 0
#define TRUE 1
int G[GPOLYNUM] = {1,0,0,0,0,0,1,0,0,1,1,0,0,0,0,0,1,0,0,0,1,1,1,0,1,1,0,1,1,0,1,1,1};


void appendZeroBytes(int *messageInBytes, int *zeroAppendedMessageInBytes, int nBytesMessage, int totalCRCedMessageBytes)
{
	int x;
	for(x = 0; x < nBytesMessage; x++)
	{
		zeroAppendedMessageInBytes[x] = messageInBytes[x];
	}
	while(x < totalCRCedMessageBytes)
	{
		zeroAppendedMessageInBytes[x] = 0;
		x++;
	}
}

void convertNumberToBits(int number, int *numberInBits)
{
	int temp = number;
	int i;
	for(i = 7; i >= 0; i--)
	{
		numberInBits[i] = temp % 2;
		temp = temp / 2;
	}
}

void convertByteMessageToBits(int *zeroAppendedMessageInBytes, int *zeroAppendedMessageInBits, int totalCRCedMessageBits)
{
	int i = 0, j, number;
	int numberInBits[8];
	printf("\nZERO APPENDED MESSAGE:\n");
	while(i < totalCRCedMessageBits)
	{
		number = zeroAppendedMessageInBytes[i/8];
		convertNumberToBits(number, numberInBits);
		for(j = 0; j < 8; j++)
		{
			zeroAppendedMessageInBits[i] = numberInBits[j]; 
			i++;
			printf("%d", numberInBits[j]);
		}
		printf("\n");
	}
}


void duplicateMessageInBits(int *input, int *output, int size)
{
	int i = 0;
	while(i < size)
	{
		output[i] = input[i];
		i++;
	}
}

void getCRC32Remainder(int *zeroAppendedMessageInBits, int *crc32RemainderInBits, int totalCRCedMessageBits)
{
	duplicateMessageInBits(zeroAppendedMessageInBits, crc32RemainderInBits, totalCRCedMessageBits);
	
	//calculation of crc
	int k, p, r, q, prev = 0;
	int tag = 0;
	
	//jump to 1st one
	while(tag < totalCRCedMessageBits)
	{
		if(crc32RemainderInBits[tag] == 1)
		{
			break;
		}
		else
		{
			tag++;
		}
	}
	
	k = tag;
	while((tag+GPOLYNUM-1) < totalCRCedMessageBits)
	{ 
		k = tag;
		for(p = 0; p < GPOLYNUM; p++)
		{
			r = (crc32RemainderInBits[k] + G[p]) % 2;
			if(r == 0 && (p == 0 || prev == 0))
			{
				prev = 0;
				tag++;
			}
			else
			{
				prev = 1;
			}
			
			crc32RemainderInBits[k] = r;
			k++;
		}
	}
}

int main()
{
	//inputs
	int nBytesMessage;
	printf("#message bytes: ");
	scanf("%d", &nBytesMessage);
	
	int messageInBytes[nBytesMessage];
	int i;
	for(i = 0; i < nBytesMessage; i++)
	{
		scanf("%d", messageInBytes+i);
	}
	
	//encoding the message
	//crc32 - 4 byte zero appended
	int totalCRCedMessageBytes = nBytesMessage + 4;
	int totalCRCedMessageBits = totalCRCedMessageBytes * 8;
	int zeroAppendedMessageInBytes[totalCRCedMessageBytes];
	int zeroAppendedMessageInBits[totalCRCedMessageBits];
	
	appendZeroBytes(messageInBytes, zeroAppendedMessageInBytes, nBytesMessage, totalCRCedMessageBytes);
	convertByteMessageToBits(zeroAppendedMessageInBytes, zeroAppendedMessageInBits, totalCRCedMessageBits);
	
	int crc32RemainderInBits[totalCRCedMessageBits];
	getCRC32Remainder(zeroAppendedMessageInBits, crc32RemainderInBits, totalCRCedMessageBits); 
	printf("\nSENDER SIDE CRC32 REMAINDER:\n");
	int k1;
	for(k1 = 0; k1 < totalCRCedMessageBits; k1++)
	{
		printf("%d ", crc32RemainderInBits[k1]);
	}
	printf("\n");
	
	int finalCRC32AppendedMessageInBits[totalCRCedMessageBits];
	
	int j;
	for(j = 0; j < totalCRCedMessageBits; j++)
	{
		finalCRC32AppendedMessageInBits[j] = zeroAppendedMessageInBits[j] + crc32RemainderInBits[j];
	}
	
	printf("\nSENDER SIDE CRC32 APPENDED MESSAGE:\n");
	int k2;
	for(k2 = 0; k2 < totalCRCedMessageBits; k2++)
	{
		printf("%d ", finalCRC32AppendedMessageInBits[k2]);
	}
	printf("\n");
	
	//decoding the message
	int receivedrCrc32RemainderInBits[totalCRCedMessageBits];
	getCRC32Remainder(finalCRC32AppendedMessageInBits, receivedrCrc32RemainderInBits, totalCRCedMessageBits); 
	printf("\nRECEIVER SIDE CRC32 REMAINDER:\n");
	int k;
	for(k = 0; k < totalCRCedMessageBits; k++)
	{
		printf("%d ", receivedrCrc32RemainderInBits[k]);
	}
	printf("\n");
	
	
	
	return 0;
}
