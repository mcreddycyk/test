#include<stdio.h>


void rc4Algo(int *key, int keyLength, int *streamBytes, int streamLength)
{

	//state and temp vector
	int S[256], T[256];

	int counter = 0;

	//initialization
	int i;
	for(i = 0; i < 256; i++)
	{
		S[i] = i;
		T[i] = key[i % keyLength];
	}

	//permutation
	int temp, j = 0;
	for(i = 0; i < 256; i++)
	{
		j = (j + S[i] + T[i]) % 256;

		//swap S[i], S[j]
		temp = S[i];
		S[i] = S[j];
		S[j] = temp;
	}

	//byte steam generation
	i = 0; j = 0;

	int k, t;
	while(counter < streamLength)
	{
		i = (i+1) % 256;
		j = (j + S[i]) % 256;

		//swap S[i], S[j]
		temp = S[i];
		S[i] = S[j];
		S[j] = temp;

		t = (S[i] + S[j]) % 256;
		k = S[t];

		streamBytes[counter] = k;

		counter++;
	}

}

int main()
{

	int keyLength = 8;
	int streamLength, key[8] = {2, 4, 9, 7, 1, 1, 3, 4};
	streamLength = 14;

	int streamBytes[streamLength];

	
	rc4Algo(key, keyLength, streamBytes, streamLength);


	int i;
	for(i = 0; i < streamLength; i++)
	{
		printf("%d\n", streamBytes[i]);
	}

}