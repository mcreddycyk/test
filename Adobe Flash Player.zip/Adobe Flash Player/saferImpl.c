#include<stdio.h>
#include<math.h>

int main()
{
	int key1[16] = {0, 11, 12, 111, 45, 5, 33, 123, 89, 98, 7, 34,	1, 70, 45, 68};
	
	int i;
	printf("KEY1 :::\n");
	for(i = 0; i < 16; i++)
	{
		printf("%d ", key1[i]);
	}
	printf("\n");
	
	int key2[16] = {10, 3, 44, 64, 45, 5, 33, 123, 55, 14, 0, 5, 90, 1, 1, 32};
	printf("\nKEY2 :::\n");
	for(i = 0; i < 16; i++)
	{
		printf("%d ", key2[i]);
	}
	
	int plainText[16] = {0, 11, 12, 111, 45, 5, 33, 123, 89, 98, 7, 34,	1, 70, 45, 68};
	
	int x0 = plainText[0] ^ key1[0];
	
	int x1 = (plainText[1] + key1[1]) % 256; 
	int x2 = (plainText[2] + key1[2]) % 256;
	
	int x3 = plainText[3] ^ key1[3];
	int x4 = plainText[4] ^ key1[4];
	
	int x5 = (plainText[5] + key1[5]) % 256; 
	int x6 = (plainText[6] + key1[6]) % 256;
	
	int x7 = plainText[7] ^ key1[7];
	int x8 = plainText[8] ^ key1[8];
	
	int x9 = (plainText[9] + key1[9]) % 256; 
	int x10 = (plainText[10] + key1[10]) % 256;
	
	int x11 = plainText[11] ^ key1[11];
	int x12 = plainText[12] ^ key1[12];
	
	int x13 = (plainText[13] + key1[13]) % 256; 
	int x14 = (plainText[14] + key1[14]) % 256;
	
	int x15 = plainText[15] ^ key1[15];
	
	///////////////////////////
	x0 = (int ) pow(45, x0) % 257;
	
	x1 = ((int ) log(x1)) % 257;
	x2 = ((int ) log(x2)) % 257;
	
	x3 = (int ) pow(45, x3) % 257;
	x4 = (int ) pow(45, x4) % 257;
	
	x5 = ((int ) log(x5)) % 257;
	x6 = ((int ) log(x6)) % 257;
	
	x7 = (int ) pow(45, x7) % 257;
	x8 = (int ) pow(45, x8) % 257;
	
	x9 = ((int ) log(x9)) % 257;
	x10 = ((int ) log(x10)) % 257;
	
	x11 = (int ) pow(45, x11) % 257;
	x12 = (int ) pow(45, x12) % 257;
	
	x13 = ((int ) log(x13)) % 257;
	x14 = ((int ) log(x14)) % 257;
	
	x15 = (int ) pow(45, x15) % 257;
	
	//////////////////////////
	 x0 = x0 ^ key2[0];
	
	 x1 = (x1 + key2[1]) % 256; 
	 x2 = (x2 + key2[2]) % 256;
	
	 x3 = x3 ^ key2[3];
	 x4 = x4 ^ key2[4];
	
	 x5 = (x5 + key2[5]) % 256; 
	 x6 = (x6 + key2[6]) % 256;
	
	 x7 = x7 ^ key2[7];
	 x8 = x8 ^ key2[8];
	
	 x9 = (x9 + key2[9]) % 256; 
	 x10 = (x10 + key2[10]) % 256;
	
	 x11 = x11 ^ key2[11];
	 x12 = x12 ^ key2[12];
	
	 x13 = (x13 + key2[13]) % 256; 
	 x14 = (x14 + key2[14]) % 256;
	
	 x15 = x15 ^ key2[15];
	
	/////////////
	int y0 = (2*x0 + x1) % 256;
	int y1 = (x0 + x1) % 256;
	
	int y2 = (2*x2 + x3) % 256;
	int y3 = (x2 + x3) % 256;
	
	int y4 = (2*x4 + x5) % 256;
	int y5 = (x4 + x5) % 256;
	
	int y6 = (2*x6 + x7) % 256;
	int y7 = (x6 + x7) % 256;
	
	int y8 = (2*x8 + x9) % 256;
	int y9 = (x8 + x9) % 256;
	
	int y10 = (2*x10 + x11) % 256;
	int y11 = (x10 + x11) % 256;
	
	int y12 = (2*x12 + x13) % 256;
	int y13 = (x12 + x13) % 256;
	
	int y14 = (2*x14 + x15) % 256;
	int y15 = (x14 + x15) % 256;
	
	x0 = y8;
	x1 = y11;
	x2 = y12;
	x3 = y15;
	x4 = y2;
	x5 = y1;
	x6 = y6;
	x7 = y5;
	x8 = y10;
	x9 = y9;
	x10 = y14;
	x11 = y13;
	x12 = y0;
	x13 = y7;
	x14 = y4;
	x15 = y3;
	
	 y0 = (2*x0 + x1) % 256;
	 y1 = (x0 + x1) % 256;
	
	 y2 = (2*x2 + x3) % 256;
	 y3 = (x2 + x3) % 256;
	
	 y4 = (2*x4 + x5) % 256;
	 y5 = (x4 + x5) % 256;
	
	 y6 = (2*x6 + x7) % 256;
	 y7 = (x6 + x7) % 256;
	
	 y8 = (2*x8 + x9) % 256;
	 y9 = (x8 + x9) % 256;
	
	 y10 = (2*x10 + x11) % 256;
	 y11 = (x10 + x11) % 256;
	
	 y12 = (2*x12 + x13) % 256;
	 y13 = (x12 + x13) % 256;
	
	 y14 = (2*x14 + x15) % 256;
	 y15 = (x14 + x15) % 256;
	 
	 printf("\n\nROUND1 OUTPUT::: \n");
	printf("%d ", y0);
	printf("%d ", y2);
	printf("%d ", y3);
	printf("%d ", y4);
	printf("%d ", y5);
	printf("%d ", y6);
	printf("%d ", y7);
	printf("%d ", y8);
	printf("%d ", y9);
	printf("%d ", y10);
	printf("%d ", y11);
	printf("%d ", y12);
	printf("%d ", y13);
	printf("%d ", y14);
	printf("%d ", y15);
}
