#include<stdio.h>
#include<math.h>

void genRand(int *filler, int n)
{
	int i;
	for(i = 0; i < n; i++)
	{
		filler[i] = rand() % 256;
	}
}

int saferAlgo(int *key1, int *plainText, int *saferOutput)
{
	int key2[16] = {10, 3, 44, 64, 45, 5, 33, 123, 55, 14, 0, 5, 90, 1, 1, 32};
	
	int x0 = plainText[0] ^ key1[0];
	
	int x1 = (plainText[1] + key1[1]) % 256; 
	int x2 = (plainText[2] + key1[2]) % 256;
	
	int x3 = plainText[3] ^ key1[3];
	int x4 = plainText[4] ^ key1[4];
	
	int x5 = (plainText[5] + key1[5]) % 256; 
	int x6 = (plainText[6] + key1[6]) % 256;
	
	int x7 = plainText[7] ^ key1[7];
	int x8 = plainText[8] ^ key1[8];
	
	int x9 = (plainText[9] + key1[9]) % 256; 
	int x10 = (plainText[10] + key1[10]) % 256;
	
	int x11 = plainText[11] ^ key1[11];
	int x12 = plainText[12] ^ key1[12];
	
	int x13 = (plainText[13] + key1[13]) % 256; 
	int x14 = (plainText[14] + key1[14]) % 256;
	
	int x15 = plainText[15] ^ key1[15];
	
	///////////////////////////
	x0 = (int ) pow(45, x0) % 257;
	
	x1 = ((int ) log(x1)) % 257;
	x2 = ((int ) log(x2)) % 257;
	
	x3 = (int ) pow(45, x3) % 257;
	x4 = (int ) pow(45, x4) % 257;
	
	x5 = ((int ) log(x5)) % 257;
	x6 = ((int ) log(x6)) % 257;
	
	x7 = (int ) pow(45, x7) % 257;
	x8 = (int ) pow(45, x8) % 257;
	
	x9 = ((int ) log(x9)) % 257;
	x10 = ((int ) log(x10)) % 257;
	
	x11 = (int ) pow(45, x11) % 257;
	x12 = (int ) pow(45, x12) % 257;
	
	x13 = ((int ) log(x13)) % 257;
	x14 = ((int ) log(x14)) % 257;
	
	x15 = (int ) pow(45, x15) % 257;
	
	//////////////////////////
	 x0 = x0 ^ key2[0];
	
	 x1 = (x1 + key2[1]) % 256; 
	 x2 = (x2 + key2[2]) % 256;
	
	 x3 = x3 ^ key2[3];
	 x4 = x4 ^ key2[4];
	
	 x5 = (x5 + key2[5]) % 256; 
	 x6 = (x6 + key2[6]) % 256;
	
	 x7 = x7 ^ key2[7];
	 x8 = x8 ^ key2[8];
	
	 x9 = (x9 + key2[9]) % 256; 
	 x10 = (x10 + key2[10]) % 256;
	
	 x11 = x11 ^ key2[11];
	 x12 = x12 ^ key2[12];
	
	 x13 = (x13 + key2[13]) % 256; 
	 x14 = (x14 + key2[14]) % 256;
	
	 x15 = x15 ^ key2[15];
	
	/////////////
	int y0 = (2*x0 + x1) % 256;
	int y1 = (x0 + x1) % 256;
	
	int y2 = (2*x2 + x3) % 256;
	int y3 = (x2 + x3) % 256;
	
	int y4 = (2*x4 + x5) % 256;
	int y5 = (x4 + x5) % 256;
	
	int y6 = (2*x6 + x7) % 256;
	int y7 = (x6 + x7) % 256;
	
	int y8 = (2*x8 + x9) % 256;
	int y9 = (x8 + x9) % 256;
	
	int y10 = (2*x10 + x11) % 256;
	int y11 = (x10 + x11) % 256;
	
	int y12 = (2*x12 + x13) % 256;
	int y13 = (x12 + x13) % 256;
	
	int y14 = (2*x14 + x15) % 256;
	int y15 = (x14 + x15) % 256;
	
	x0 = y8;
	x1 = y11;
	x2 = y12;
	x3 = y15;
	x4 = y2;
	x5 = y1;
	x6 = y6;
	x7 = y5;
	x8 = y10;
	x9 = y9;
	x10 = y14;
	x11 = y13;
	x12 = y0;
	x13 = y7;
	x14 = y4;
	x15 = y3;
	
	 y0 = (2*x0 + x1) % 256;
	 y1 = (x0 + x1) % 256;
	
	 y2 = (2*x2 + x3) % 256;
	 y3 = (x2 + x3) % 256;
	
	 y4 = (2*x4 + x5) % 256;
	 y5 = (x4 + x5) % 256;
	
	 y6 = (2*x6 + x7) % 256;
	 y7 = (x6 + x7) % 256;
	
	 y8 = (2*x8 + x9) % 256;
	 y9 = (x8 + x9) % 256;
	
	 y10 = (2*x10 + x11) % 256;
	 y11 = (x10 + x11) % 256;
	
	 y12 = (2*x12 + x13) % 256;
	 y13 = (x12 + x13) % 256;
	
	 y14 = (2*x14 + x15) % 256;
	 y15 = (x14 + x15) % 256;
	 
	saferOutput[0] = y0;
	saferOutput[1] = y1;
	saferOutput[2] = y2;
	saferOutput[3] = y3;

	saferOutput[4] = y4;
	saferOutput[5] = y5;
	saferOutput[6] = y6;
	saferOutput[7] = y7;
	  
	saferOutput[8] = y8;
	saferOutput[9] = y9;
	saferOutput[10] = y10;
	saferOutput[11] = y11;
	
	saferOutput[12] = y12;
	saferOutput[13] = y13;
	saferOutput[14] = y14;
	saferOutput[15] = y15;
}

int main()
{
	//key generation
	int key[16];
	genRand(key, 16);
	
	printf("KEY: \n");
	int i;
	for(i = 0; i < 16; i++)
	{
		printf("%d ", key[i]);
	}
	printf("\n\n");
	
	//key offset
	int keyOffset[16];
	
	keyOffset[0] = (key[0] ^ 233) % 256;
	keyOffset[1] = (key[1] ^ 229) % 256;
	keyOffset[2] = (key[2] ^ 233) % 256;
	keyOffset[3] = (key[3] ^ 193) % 256;
	keyOffset[4] = (key[4] ^ 179) % 256;
	keyOffset[5] = (key[5] ^ 167) % 256;
	keyOffset[6] = (key[6] ^ 149) % 256;
	keyOffset[7] = (key[7] ^ 131) % 256;
	
	keyOffset[8] = (key[8] + 233) % 256;
	keyOffset[9] = (key[9] + 229) % 256;
	keyOffset[10] = (key[10] + 233) % 256;
	keyOffset[11] = (key[11] + 193) % 256;
	keyOffset[12] = (key[12] + 179) % 256;
	keyOffset[13] = (key[13] + 167) % 256;
	keyOffset[14] = (key[14] + 149) % 256;
	keyOffset[15] = (key[15] + 131) % 256;
	
	int randi[16];
	genRand(randi, 16);
	
	int saferOutput[16];
	saferAlgo(key, randi, saferOutput);
	
	int j, saferOpExored[16];
	for(j = 0; j < 16; j++)
	{
		saferOpExored[j] = (saferOutput[j] ^ randi[j]) % 256;
	}
	
	int addr[16];
	genRand(addr, 16);
	printf("ADDRESS: \n");
	for(j = 0; j < 16; j++)
	{
		printf("%d ", addr[j]);
	}
	printf("\n\n");
	
	int saferOpModAdd[16];
	for(j = 0; j < 16; j++)
	{
		saferOpModAdd[j] = (saferOpExored[j] + addr[j]) % 256;
	}
	
	int saferDashOutput[16];
	saferAlgo(keyOffset, saferOpModAdd, saferDashOutput);
	
	int ACO[12];
	for(j = 0; j < 12; j++)
	{
		ACO[j] = saferDashOutput[j];
	}
	
	int SRES[4];
	for(j = 12; j < 16; j++)
	{
		SRES[j-12] = saferDashOutput[j];
	}
	
	printf("ACO: \n");
	for(j = 0; j < 12; j++)
	{
		if(ACO[j] < 0)
		{
			ACO[j] = -1 * ACO[j];
		}
		printf("%d ", ACO[j]);
		
	}
	printf("\n\n");
	
	printf("SRES: \n");
	for(j = 0; j < 4; j++)
	{
		if(SRES[j] < 0)
		{
			SRES[j] = -1 * SRES[j];
		}
		printf("%d ", SRES[j]);
	}	
	printf("\n\n");
	
}