#include<stdio.h>
#include<math.h>
#include<stdlib.h>

static const int table_0[512] = {
        102,177,186,162,  2,156,112, 75, 55, 25,  8, 12,251,193,246,188,
        109,213,151, 53, 42, 79,191,115,233,242,164,223,209,148,108,161,
        252, 37,244, 47, 64,211,  6,237,185,160,139,113, 76,138, 59, 70,
         67, 26, 13,157, 63,179,221, 30,214, 36,166, 69,152,124,207,116,
        247,194, 41, 84, 71,  1, 49, 14, 95, 35,169, 21, 96, 78,215,225,
        182,243, 28, 92,201,118,  4, 74,248,128, 17, 11,146,132,245, 48,
        149, 90,120, 39, 87,230,106,232,175, 19,126,190,202,141,137,176,
        250, 27,101, 40,219,227, 58, 20, 51,178, 98,216,140, 22, 32,121,
         61,103,203, 72, 29,110, 85,212,180,204,150,183, 15, 66,172,196,
         56,197,158,  0,100, 45,153,  7,144,222,163,167, 60,135,210,231,
        174,165, 38,249,224, 34,220,229,217,208,241, 68,206,189,125,255,
        239, 54,168, 89,123,122, 73,145,117,234,143, 99,129,200,192, 82,
        104,170,136,235, 93, 81,205,173,236, 94,105, 52, 46,228,198,  5,
         57,254, 97,155,142,133,199,171,187, 50, 65,181,127,107,147,226,
        184,218,131, 33, 77, 86, 31, 44, 88, 62,238, 18, 24, 43,154, 23,
         80,159,134,111,  9,114,  3, 91, 16,130, 83, 10,195,240,253,119,
        177,102,162,186,156,  2, 75,112, 25, 55, 12,  8,193,251,188,246,
        213,109, 53,151, 79, 42,115,191,242,233,223,164,148,209,161,108,
         37,252, 47,244,211, 64,237,  6,160,185,113,139,138, 76, 70, 59,
         26, 67,157, 13,179, 63, 30,221, 36,214, 69,166,124,152,116,207,
        194,247, 84, 41,  1, 71, 14, 49, 35, 95, 21,169, 78, 96,225,215,
        243,182, 92, 28,118,201, 74,  4,128,248, 11, 17,132,146, 48,245,
         90,149, 39,120,230, 87,232,106, 19,175,190,126,141,202,176,137,
         27,250, 40,101,227,219, 20, 58,178, 51,216, 98, 22,140,121, 32,
        103, 61, 72,203,110, 29,212, 85,204,180,183,150, 66, 15,196,172,
        197, 56,  0,158, 45,100,  7,153,222,144,167,163,135, 60,231,210,
        165,174,249, 38, 34,224,229,220,208,217, 68,241,189,206,255,125,
         54,239, 89,168,122,123,145, 73,234,117, 99,143,200,129, 82,192,
        170,104,235,136, 81, 93,173,205, 94,236, 52,105,228, 46,  5,198,
        254, 57,155, 97,133,142,171,199, 50,187,181, 65,107,127,226,147,
        218,184, 33,131, 86, 77, 44, 31, 62, 88, 18,238, 43, 24, 23,154,
        159, 80,111,134,114,  9, 91,  3,130, 16, 10, 83,240,195,119,253
    }, table_1[256] = {
         19, 11, 80,114, 43,  1, 69, 94, 39, 18,127,117, 97,  3, 85, 43,
         27,124, 70, 83, 47, 71, 63, 10, 47, 89, 79,  4, 14, 59, 11,  5,
         35,107,103, 68, 21, 86, 36, 91, 85,126, 32, 50,109, 94,120,  6,
         53, 79, 28, 45, 99, 95, 41, 34, 88, 68, 93, 55,110,125,105, 20,
         90, 80, 76, 96, 23, 60, 89, 64,121, 56, 14, 74,101,  8, 19, 78,
         76, 66,104, 46,111, 50, 32,  3, 39,  0, 58, 25, 92, 22, 18, 51,
         57, 65,119,116, 22,109,  7, 86, 59, 93, 62,110, 78, 99, 77, 67,
         12,113, 87, 98,102,  5, 88, 33, 38, 56, 23,  8, 75, 45, 13, 75,
         95, 63, 28, 49,123,120, 20,112, 44, 30, 15, 98,106,  2,103, 29,
         82,107, 42,124, 24, 30, 41, 16,108,100,117, 40, 73, 40,  7,114,
         82,115, 36,112, 12,102,100, 84, 92, 48, 72, 97,  9, 54, 55, 74,
        113,123, 17, 26, 53, 58,  4,  9, 69,122, 21,118, 42, 60, 27, 73,
        118,125, 34, 15, 65,115, 84, 64, 62, 81, 70,  1, 24,111,121, 83,
        104, 81, 49,127, 48,105, 31, 10,  6, 91, 87, 37, 16, 54,116,126,
         31, 38, 13,  0, 72,106, 77, 61, 26, 67, 46, 29, 96, 37, 61, 52,
        101, 17, 44,108, 71, 52, 66, 57, 33, 51, 25, 90,  2,119,122, 35
    }, table_2[128] = {
         52, 50, 44,  6, 21, 49, 41, 59, 39, 51, 25, 32, 51, 47, 52, 43,
         37,  4, 40, 34, 61, 12, 28,  4, 58, 23,  8, 15, 12, 22,  9, 18,
         55, 10, 33, 35, 50,  1, 43,  3, 57, 13, 62, 14,  7, 42, 44, 59,
         62, 57, 27,  6,  8, 31, 26, 54, 41, 22, 45, 20, 39,  3, 16, 56,
         48,  2, 21, 28, 36, 42, 60, 33, 34, 18,  0, 11, 24, 10, 17, 61,
         29, 14, 45, 26, 55, 46, 11, 17, 54, 46,  9, 24, 30, 60, 32,  0,
         20, 38,  2, 30, 58, 35,  1, 16, 56, 40, 23, 48, 13, 19, 19, 27,
         31, 53, 47, 38, 63, 15, 49,  5, 37, 53, 25, 36, 63, 29,  5,  7
    }, table_3[64] = {
          1,  5, 29,  6, 25,  1, 18, 23, 17, 19,  0,  9, 24, 25,  6, 31,
         28, 20, 24, 30,  4, 27,  3, 13, 15, 16, 14, 18,  4,  3,  8,  9,
         20,  0, 12, 26, 21,  8, 28,  2, 29,  2, 15,  7, 11, 22, 14, 10,
         17, 21, 12, 30, 26, 27, 16, 31, 11,  7, 13, 23, 10,  5, 22, 19
    }, table_4[32] = {
         15, 12, 10,  4,  1, 14, 11,  7,  5,  0, 14,  7,  1,  2, 13,  8,
         10,  3,  4,  9,  6,  0,  3,  2,  5,  6,  8,  9, 11, 13, 15, 12
    }, *table[5] = { table_0, table_1, table_2, table_3, table_4 };
    
void roundFunction(int X[])
{

    int N, A_out, B_out, indexA, indexB, offset, associatedElementIndex, modValue;
    for(N = 0; N <= 4; N++)
    {
//        printf("ROUND ---- %d\n", N);
        int i = 0;
        for(i = 0; i < 32; i++)
        {
            offset    = (int) pow(2, 4-N);
        
            associatedElementIndex = i + offset;
            modValue = (int) pow(2, 9-N);
            indexA = ((X[i] + 2*X[associatedElementIndex]) % modValue);
//            printf("- %d \n", table[N][indexA]);
            
            
            indexB = ((X[associatedElementIndex] + 2*X[i]) % modValue);
            
//            printf("- %d \n", table[N][indexB]);
            X[i] = table[N][indexA];
            X[associatedElementIndex]  = table[N][indexB];
            
            //printf("\t(%d, %d) \n", indexA, indexB);
            
            if((associatedElementIndex+1) % (offset*2) == 0)
            {
                i = associatedElementIndex;
            }
        }
        /*
        printf("Level: %d\n", N);
        for(i = 0; i < 32; i++)
        {
        	printf("%d\n", X[i]);
        }
        */
    }
    
    int i;
    for(i = 0; i < 32; i++)
    {
        //printf("[%d] - %d\n", i, X[i]);
    }
    
    
}

void permute(int bit[], int x[])
{
	int j, k, next_bit;
    for (j=0; j<16; j++) {
				x[j+16] = 0;
				for (k=0; k<8; k++) {
					next_bit = ((8*j + k)*17) % 128;
					x[j+16] |= bit[next_bit] << (7-k);
				}
			}
}

void comp128(int keyRandBytes[32], int finalResult[96])
{

	//round function
	int X[32]; //copyof keyRandBytes
	int p, i;
    for(p = 0; p <= 31; p++)
    {
    	X[p] = keyRandBytes[p];
    }

	int roundNo;
	for(roundNo = 0; roundNo < 8; roundNo++)
	{

		//after round permute wala code
		for(i = 0 ; i < 16; i++)
		{
			X[i] = keyRandBytes[i];

		}
		
	    roundFunction(X);


	    //32*8 => 32*4
	    int result[128];
	    int j,k;
	    for(j = 0; j <= 31; j++)
	    {
	        for(k = 0; k <= 3; k++)
	        {
	            result[4*j + k] = (X[j] >> (3-k)) & 1;
	        }
	    }
	    
	    
	    if(roundNo < 7)
	    {
		    permute(result, X);
		}
	   	else
	   	{
	   		for(i = 0; i < 96; i++)
	   		{
	   			finalResult[i] = result[i];
	   		}
		}
	}
	
}

int compare(int value[], int valueDash[])
{
	int i;
	for(i = 0; i < 24; i++)
	{
		if(value[i] != valueDash[i])
		{
			return 0;
		}
	}
	
	return 1;
}


void collisionTest(int keyRandBytes[])
{
	//round function
	int X[32]; //copyof keyRandBytes
	int p;
    for(p = 0; p <= 31; p++)
    {
    	X[p] = keyRandBytes[p];
    }

    int i, j, keyIndex, currentResult[96], refResult[96], k, count, i1, j1;
    int collisionIndexRecord[8][2];
    for(keyIndex = 0; keyIndex < 8; keyIndex++)
    {
        printf("i = %d\n", keyIndex);
    	for(i = 0; i < 256; i++)
	    {
	    	for(j = 0; j < 256; j++)
	    	{
	    		
                X[keyIndex + 16] = i;
                X[keyIndex + 16 + 8] = j;

                comp128(X, currentResult);

                

                for(i1 = 0; i1 < 256; i1++)
                {
                    for(j1 = 0; j1 < 256; j1++)
                    {
                        if(i != i1 && j != j1)
                        {
                            count = 0;
                            X[keyIndex + 16] = i1;
                            X[keyIndex + 16 + 8] = j1;
                            comp128(X, refResult);

                            for(k = 0; k < 96; k++)
                            {
                                if(currentResult[k] == refResult[k])
                                {
                                    count++;
                                }
                                else
                                {
                                    break;
                                }
                            }

                            if(count == 96)
                            {
                                printf("rand collision.. (%d, %d), (%d, %d)\n\n", i, j, i1, j1);
                                collisionIndexRecord[keyIndex][0] = i; collisionIndexRecord[keyIndex][1] = j; 
                                goto lbl;
                            }
                    
                        }
        	    	}
        	    }

        	    
            }
        }

        lbl:
        X[keyIndex + 16] = keyRandBytes[keyIndex + 16];
        X[keyIndex + 16 + 8] = keyRandBytes[keyIndex + 16 + 8];
    }

    for(keyIndex = 0; keyIndex < 8; keyIndex++)
    {
        X[keyIndex + 16] = collisionIndexRecord[keyIndex][0];
        X[keyIndex + 16 + 8] = collisionIndexRecord[keyIndex][1];

        printf("i = %d\n", keyIndex);
        for(i = 0; i < 256; i++)
        {
            for(j = 0; j < 256; j++)
            {
                
                X[keyIndex] = i;
                X[keyIndex + 8] = j;
                
                comp128(X, currentResult);

                

                for(i1 = 0; i1 < 256; i1++)
                {
                    for(j1 = 0; j1 < 256; j1++)
                    {
                        if(i != i1 && j != j1)
                        {
                            count = 0;
                            X[keyIndex] = i1;
                            X[keyIndex + 8] = j1;
                            comp128(X, refResult);

                            for(k = 0; k < 96; k++)
                            {
                                if(currentResult[k] == refResult[k])
                                {
                                    count++;
                                }
                                else
                                {
                                    break;
                                }
                            }

                            if(count == 96)
                            {
                                printf("key collision.. (%d, %d), (%d, %d)\n\n", i, j, i1, j1);
                                goto lbl;
                            }

                        }
                    }
                }

                X[keyIndex] = keyRandBytes[keyIndex];
                X[keyIndex + 8] = keyRandBytes[keyIndex + 8];
            }
        }

        lbl:
        X[keyIndex + 16] = keyRandBytes[keyIndex + 16];
        X[keyIndex + 16 + 8] = keyRandBytes[keyIndex + 16 + 8];
    }
    
}


int main() {
    //key + rand = 16 + 16 Byte
    int keyRandBytes[32] = {192, 16, 42, 136, 170, 26, 51, 241, 164, 206, 138, 136, 228, 241, 71, 118, 76, 17, 196, 167, 185, 149, 126, 179, 184, 23, 210, 124, 212, 218, 177, 58};
   
    collisionTest(keyRandBytes);
}

//ref: http://www.scard.org/gsm/a3a8.txt
