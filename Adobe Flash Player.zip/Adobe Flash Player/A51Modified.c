#include<stdio.h>
#include<stdlib.h>

void generateRandomBits(int *filler, int size)
{
	int i, randBit;
	//printf("\n BITS GENERATED :\n");
	for(i = 0; i < size; i++)
	{
		randBit = rand() % 2;
		//printf("%d ", randBit);
		filler[i] = randBit;
	}
}

int main()
{
	int kCSize = 64, fNSize = 22, pTSize = 228;
	int kC[kCSize], fN[fNSize], plainText[pTSize], cipherText[pTSize];

	generateRandomBits(kC, kCSize); generateRandomBits(fN, fNSize); generateRandomBits(plainText, pTSize);

	int R1[19] = {0}, R2[22] = {0}, R3[23] = {0};


	int i, inputBit, input64RoundsR1, input64RoundsR2, input64RoundsR3, prev1, prev2, prev3, tempR1, tempR2, tempR3, j1, j2, j3;

	//64 rounds based on kC, 22 rounds based on fN
	//printf("\n===\n");
	for(i = 0; i < (64+22); i++)
	{

		if(i < 64)
		{
			inputBit = kC[i];
		}
		else
		{
			inputBit = fN[i-64];
		}

		input64RoundsR1 = inputBit ^ R1[13] ^ R1[16] ^ R1[17] ^ R1[18];
		input64RoundsR2 = inputBit ^ R2[20] ^ R2[21];
		input64RoundsR3 = inputBit ^ R3[7] ^ R3[20] ^ R3[21] ^ R3[22];
	
        //printf("%d %d %d %d\n", inputBit, input64RoundsR1, input64RoundsR2, input64RoundsR3);

		prev1 = R1[0];
		//shifting
		for(j1 = 0; j1 < 18; j1++)
		{
			tempR1 = R1[j1+1];
			R1[j1+1] = prev1;
			prev1 = tempR1;
		}
		R1[0] = input64RoundsR1;

		prev2 = R2[0];
		for(j2 = 0; j2 < 21; j2++)
		{
			tempR2 = R2[j2+1];
			R2[j2+1] = prev2;
			prev2 = tempR2;
		}
		R2[0] = input64RoundsR2;

		prev3 = R3[0];
		for(j3 = 0; j3 < 22; j3++)
		{
			tempR3 = R2[j3+1];
			R3[j3+1] = prev3;
			prev3 = tempR3;
		}
		R3[0] = input64RoundsR3;
	}
	
	//majority function based register clocking
	int enableR1, enableR2, enableR3, c1, c2, c3;
	int keyStream[114+144];
	//printf("==\n===");

	for(i = 0; i < (100+228); i++)
	{
		//majority function
		c1 = R1[8]; c2 = R2[10]; c3 = R3[10];
		if(c1 == 0 && c2 == 0 && c3 == 0)
		{
			enableR1 = 1, enableR2 = 1, enableR3 = 1;
		}else if(c1 == 0 && c2 == 0 && c3 == 1){
			enableR1 = 1, enableR2 = 1, enableR3 = 0;
		}else if(c1 == 0 && c2 == 1 && c3 == 0){
			enableR1 = 1, enableR2 = 0, enableR3 = 1;
		}else if(c1 == 0 && c2 == 1 && c3 == 1){
			enableR1 = 0, enableR2 = 1, enableR3 = 1;
		}else if(c1 == 1 && c2 == 0 && c3 == 0){
			enableR1 = 0, enableR2 = 1, enableR3 = 1;
		}else if(c1 == 1 && c2 == 0 && c3 == 1){
			enableR1 = 1, enableR2 = 0, enableR3 = 1;
		}else if(c1 == 1 && c2 == 1 && c3 == 0){
			enableR1 = 1, enableR2 = 1, enableR3 = 0;
		}else if(c1 == 1 && c2 == 1 && c3 == 1){
			enableR1 = 1, enableR2 = 1, enableR3 = 1;
		}

		input64RoundsR1 = R1[13] ^ R1[16] ^ R1[17] ^ R1[18];
		input64RoundsR2 = R2[20] ^ R2[21];
		input64RoundsR3 = R3[7] ^ R3[20] ^ R3[21] ^ R3[22];

        //printf("%d %d %d\n", input64RoundsR1, input64RoundsR2, input64RoundsR3);

		//capturing MSB for output calculation before shift
		if(i >= 100)
		{
			keyStream[i-100] = R1[18] ^ R2[21] ^ R3[22];
		}

		
		if(i < 100 || enableR1)
		{
			prev1 = R1[0];
			//shifting
			for(j1 = 0; j1 < 18; j1++)
			{
				tempR1 = R1[j1+1];
				R1[j1+1] = prev1;
				prev1 = tempR1;
			}
			R1[0] = input64RoundsR1;
		}

		if(i < 100 || enableR2)
		{
			prev2 = R2[0];
			for(j2 = 0; j2 < 21; j2++)
			{
				tempR2 = R2[j2+1];
				R2[j2+1] = prev2;
				prev2 = tempR2;
			}
			R2[0] = input64RoundsR2;
		}

		if(i < 100 || enableR3)
		{
			prev3 = R3[0];
			for(j3 = 0; j3 < 22; j3++)
			{
				tempR3 = R3[j3+1];
				R3[j3+1] = prev3;
				prev3 = tempR3;
			}
			R3[0] = input64RoundsR3;
		}
	}

	printf("\nKEY STREAM [228 BIT] ::\n");
	int j;
	for(j = 0; j < 228; j++)
	{
		printf("%d", keyStream[j]);
		cipherText[j] = keyStream[j] ^ plainText[j];
	}
	printf("\n");
	
	printf("\nPlaintext:: \n");
	for(j1 = 0; j1 < 228; j1++)
	{
		printf("%d", plainText[j1]);
	} 
	printf("\n");
	
	printf("\nCiphertext:: \n");
	for(j1 = 0; j1 < 228; j1++)
	{
		printf("%d", cipherText[j1]);
	} 
	printf("\n");
	
}
